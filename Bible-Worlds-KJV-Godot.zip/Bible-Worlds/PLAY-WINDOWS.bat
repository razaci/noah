@echo off
setlocal
cd /d "%~dp0"
if exist "godot.exe" (
  start "Bible Worlds" "godot.exe" --path "%~dp0" --editor
  exit /b
)
where godot >nul 2>nul
if not errorlevel 1 (
  start "Bible Worlds" godot --path "%~dp0" --editor
  exit /b
)
echo Select your Godot 4 executable. Standard Godot is sufficient.
echo The editor will open this project. Wait for imports, then press F5.
powershell -NoProfile -STA -Command "Add-Type -AssemblyName System.Windows.Forms; $pick = New-Object System.Windows.Forms.OpenFileDialog; $pick.Title = 'Select Godot 4 executable'; $pick.Filter = 'Godot executable (*.exe)|*.exe'; if ($pick.ShowDialog() -eq 'OK') { Start-Process -FilePath $pick.FileName -ArgumentList @('--path', ([char]34 + (Get-Location).Path + [char]34), '--editor') }"

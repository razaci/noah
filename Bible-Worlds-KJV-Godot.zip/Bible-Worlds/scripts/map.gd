extends Control

var spots: Array = []
var seen: Dictionary = {}
var player_position := Vector3.ZERO
var player_yaw := 0.0
var chapter := 0
var chosen := ""
signal waypoint_selected(id: String)
var font: Font = ThemeDB.fallback_font

func _ready() -> void:
	custom_minimum_size = Vector2(600, 300)
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	resized.connect(queue_redraw)

func point(pos: Vector3) -> Vector2:
	var scale_factor := minf(size.x / 165, size.y / 145)
	return Vector2(size.x / 2 + pos.x * scale_factor, size.y / 2 + pos.z * scale_factor)

func landmark(center: Vector3, extent: Vector2, color: Color, title: String) -> void:
	var factor := minf(size.x / 165, size.y / 145)
	var p := point(center)
	var box_size := extent * factor
	draw_rect(Rect2(p - box_size / 2, box_size), color)
	draw_string(font, p - box_size / 2 + Vector2(5, -5), title, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color("9eafb5"))

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("142630"))
	for x in range(-70, 81, 10):
		draw_line(point(Vector3(x, 0, -70)), point(Vector3(x, 0, 70)), Color("213943"))
	for z in range(-70, 71, 10):
		draw_line(point(Vector3(-80, 0, z)), point(Vector3(80, 0, z)), Color("213943"))
	match chapter:
		0, 1:
			landmark(Vector3(0, 0, -8), Vector2(20, 48), Color("67503d"), "ARK")
		3:
			landmark(Vector3(0, 0, -28), Vector2(22, 18), Color("675f46"), "PALACE")
			landmark(Vector3(-27, 0, 1), Vector2(13, 13), Color("474c52"), "PRISON")
			landmark(Vector3(29, 0, 1), Vector2(15, 16), Color("716245"), "GRANARY")
		5:
			landmark(Vector3(-19, 0, -12), Vector2(22, 66), Color("245069"), "SEA")
			landmark(Vector3(19, 0, -12), Vector2(22, 66), Color("245069"), "SEA")
		6:
			landmark(Vector3(0, 0, -42), Vector2(45, 35), Color("535550"), "SINAI")
		7:
			landmark(Vector3(-11, 0, 3), Vector2(7, 64), Color("245069"), "BROOK")
		8:
			draw_circle(point(Vector3(0, 0, -6)), minf(size.x / 165, size.y / 145) * 15, Color("4a4850"))
		9:
			landmark(Vector3(-24, 0, 2), Vector2(8, 55), Color("67503d"), "SHIP / PIER")
			landmark(Vector3(28, 0, -8), Vector2(7, 24), Color("65535c"), "FISH CHAMBER")
			landmark(Vector3(0, 0, -52), Vector2(30, 9), Color("6b604b"), "NINEVEH")
	for s in spots:
		var p := point(s.pos)
		var color := Color("7fbc9c") if seen.has(s.id) else Color("e8c788")
		draw_circle(p, 5, color)
		if s.id == chosen:
			draw_arc(p, 10, 0, TAU, 30, Color("ffffff"), 2, true)
		# Five brook stones are numbered so they remain legible without overlapping labels.
		var title: String = s.title
		if str(s.id).begins_with("d_stone_"):
			title = str(int(str(s.id).get_slice("_", 2)) + 1)
		draw_string(font, p + Vector2(8, -5), title, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, color)
	var p := point(player_position)
	draw_circle(p, 6, Color("8fd6e1"))
	var forward := Vector2(-sin(player_yaw), -cos(player_yaw))
	draw_line(p, p + forward * 19, Color("8fd6e1"), 3, true)
	draw_string(font, Vector2(12, 23), "NORTH  ↑    Click a gold or green marker to set your destination", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color("e2dac4"))

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		var closest := 22.0
		var id := ""
		for s in spots:
			var distance: float = point(s.pos).distance_to(event.position)
			if distance < closest:
				closest = distance
				id = s.id
		if not id.is_empty():
			waypoint_selected.emit(id)

extends Node3D

var mats: Dictionary = {}
var spots: Array = []
var animated: Array = []
var sea_left: MeshInstance3D
var sea_right: MeshInstance3D
var sea_middle: MeshInstance3D
var flame: Node3D
var flood: MeshInstance3D
var rain: MultiMeshInstance3D
var spawn := Vector3(0, 1, 25)
var rng := RandomNumberGenerator.new()
var time := 0.0
var chapter := 0
var event_started := false
var water_material: ShaderMaterial

func water() -> ShaderMaterial:
	if water_material == null:
		water_material = ShaderMaterial.new()
		water_material.shader = preload("res://scripts/water.gdshader")
	return water_material

func material(color: Color, glow: float = 0.0) -> StandardMaterial3D:
	var key := str(color) + str(glow)
	if mats.has(key):
		return mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.87
	if glow > 0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = glow
	mats[key] = m
	return m

func box(pos: Vector3, size: Vector3, color: Color, solid: bool = true, parent: Node3D = self) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	var obj := MeshInstance3D.new()
	obj.mesh = mesh
	obj.material_override = material(color)
	obj.position = pos
	parent.add_child(obj)
	if solid:
		var body := StaticBody3D.new()
		var collision := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		collision.shape = shape
		body.add_child(collision)
		obj.add_child(body)
	return obj

func sphere(pos: Vector3, size: float, color: Color, parent: Node3D = self) -> MeshInstance3D:
	var obj := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = size
	mesh.height = size * 2
	mesh.radial_segments = 12
	mesh.rings = 6
	obj.mesh = mesh
	obj.material_override = material(color)
	obj.position = pos
	parent.add_child(obj)
	return obj

func cylinder(pos: Vector3, radius: float, height: float, color: Color, top: float = -1, parent: Node3D = self) -> MeshInstance3D:
	var obj := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.bottom_radius = radius
	mesh.top_radius = radius if top < 0 else top
	mesh.height = height
	mesh.radial_segments = 10
	obj.mesh = mesh
	obj.material_override = material(color)
	obj.position = pos
	parent.add_child(obj)
	return obj

func label_at(pos: Vector3, text: String, size: int = 32) -> void:
	var l := Label3D.new()
	l.text = text
	l.position = pos
	l.font_size = size
	l.pixel_size = 0.012
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.modulate = Color("ffe2a0")
	l.outline_size = 7
	add_child(l)

func spot(id: String, title: String, pos: Vector3, ref: String, context: String, action: String = "") -> void:
	spots.append({"id": id, "title": title, "pos": pos, "ref": ref, "context": context, "action": action})
	var gem := sphere(pos + Vector3(0, 2.7, 0), 0.16, Color("ffd47b"))
	gem.material_override = material(Color("ffd47b"), 1.5)
	animated.append(gem)
	spots[-1]["marker"] = gem
	label_at(pos + Vector3(0, 3.25, 0), title, 25)

func tree(pos: Vector3, palm: bool = false) -> void:
	cylinder(pos + Vector3(0, 2, 0), 0.22, 4, Color("705239"), 0.16)
	if palm:
		for i in range(6):
			var leaf := box(pos + Vector3(0, 4.4, 0), Vector3(0.7, 0.12, 4.7), Color("578b59"), false)
			leaf.rotation = Vector3(0.2, i * TAU / 6, 0.2)
	else:
		for i in range(3):
			sphere(pos + Vector3(sin(i * 2) * 1.2, 4.0 + i * 0.5, cos(i * 2)), 1.7, Color("477c64"))

func person(pos: Vector3, name_text: String, robe: Color, parent: Node3D = self) -> void:
	cylinder(pos + Vector3(0, 0.85, 0), 0.45, 1.5, robe, 0.24, parent)
	sphere(pos + Vector3(0, 1.8, 0), 0.26, Color("bf906f"), parent)
	cylinder(pos + Vector3(0, 1.97, 0), 0.29, 0.2, Color("e7d7b3"), 0.29, parent)
	for side in [-1, 1]:
		var arm := cylinder(pos + Vector3(side * 0.34, 1.1, 0), 0.1, 0.8, robe, 0.1, parent)
		arm.rotation.z = side * 0.18
	if parent == self and not name_text.is_empty():
		label_at(pos + Vector3(0, 2.3, 0), name_text, 22)

func animal(pos: Vector3, color: Color, kind: String) -> void:
	var scale_size := 1.5 if kind == "Elephant" else 0.8
	sphere(pos + Vector3(0, scale_size, 0), scale_size, color).scale = Vector3(0.7, 0.7, 1.2)
	sphere(pos + Vector3(0, scale_size * 1.2, -scale_size), scale_size * 0.5, color)
	for x in [-0.4, 0.4]:
		for z in [-0.5, 0.5]:
			cylinder(pos + Vector3(x * scale_size, 0.35, z * scale_size), 0.11, 0.7, color)
	if kind == "Elephant":
		cylinder(pos + Vector3(0, 0.9, -2.1), 0.13, 1.2, color)
		for side in [-1, 1]:
			sphere(pos + Vector3(side * 0.65, 1.6, -1.3), 0.55, color).scale.z = 0.25

func house(pos: Vector3, size: Vector3, color: Color) -> void:
	# Three walls leave the front open so every small building can be entered.
	box(pos + Vector3(-size.x / 2, size.y / 2, 0), Vector3(0.4, size.y, size.z), color)
	box(pos + Vector3(size.x / 2, size.y / 2, 0), Vector3(0.4, size.y, size.z), color)
	box(pos + Vector3(0, size.y / 2, -size.z / 2), Vector3(size.x, size.y, 0.4), color)
	box(pos + Vector3(0, size.y, 0), Vector3(size.x + 0.6, 0.25, size.z + 0.6), color.darkened(0.15))

func landscape(desert: bool) -> void:
	var ground := Color("c5a67d") if desert else Color("6c8870")
	box(Vector3(0, -0.5, 0), Vector3(220, 1, 220), ground)
	for i in range(65):
		var a := float(i) / 65 * TAU
		var r := rng.randf_range(75, 103)
		var p := Vector3(sin(a) * r, 0, cos(a) * r)
		var h := rng.randf_range(5, 23)
		cylinder(p + Vector3(0, h / 2 - 0.5, 0), rng.randf_range(9, 18), h, ground.darkened(rng.randf_range(0.06, 0.25)), 0)
	for i in range(26):
		var p := Vector3(rng.randf_range(-65, 65), 0, rng.randf_range(-65, 65))
		if absf(p.x) < 26 and absf(p.z) < 45:
			continue
		if i % 3 == 0:
			sphere(p, rng.randf_range(0.5, 1.8), Color("958c76")).scale.y = 0.6
		else:
			tree(p, desert)

func ark(deck_only: bool = false) -> void:
	var wood := Color("805a3b")
	var deck := 7.0 if deck_only else 0.0
	box(Vector3(0, deck - 0.25, -8), Vector3(20, 0.5, 48), wood)
	for side in [-1, 1]:
		box(Vector3(side * 10, deck + 2.6, -8), Vector3(0.5, 5.5, 48), wood)
		for i in range(13):
			box(Vector3(side * 9.65, deck + 2.5, -31 + i * 3.8), Vector3(0.6, 5, 0.35), wood.lightened(0.13), false)
	box(Vector3(0, deck + 2.5, -32), Vector3(20, 5, 0.5), wood)
	if deck_only:
		box(Vector3(0, 3, -8), Vector3(19.7, 7, 47.5), wood, false)
		house(Vector3(0, deck, -20), Vector3(9, 3, 12), wood.lightened(0.1))
		spawn = Vector3(0, 8, 12)
	else:
		# Open front, central aisle and animal stalls; a partial roof keeps the interior visible.
		for side in [-1, 1]:
			for i in range(4):
				box(Vector3(side * 6.5, 1, -5 - i * 6), Vector3(5.8, 1.5, 0.25), wood)
				animal(Vector3(side * 6, 0.3, -8 - i * 6), Color("c7b89d") if i % 2 == 0 else Color("7c8790"), "Sheep" if i % 2 == 0 else "Elephant")
			box(Vector3(side * 6.5, 5.2, -8), Vector3(6.5, 0.35, 48), wood)
		spawn = Vector3(0, 1, 30)
	for i in range(10):
		box(Vector3(0, deck + 0.02, -30 + i * 4.7), Vector3(19, 0.08, 0.06), wood.darkened(0.3), false)

func build(index: int) -> void:
	chapter = index
	rng.seed = 777 + index
	landscape(index >= 2 and index != 7)
	match index:
		0:
			ark()
			person(Vector3(5, 0, 22), "Noah", Color("899fbd"))
			var timber := Node3D.new()
			timber.name = "Timber"
			add_child(timber)
			for i in range(8):
				box(Vector3(-17, 0.3 + i * 0.35, 15), Vector3(7, 0.25, 0.7), Color("9a714a"), true, timber)
			spot("ark_plan", "Meet Noah", Vector3(5, 0, 24), "Genesis 6:14", "The ark is a place of preservation. Explore its central aisle and animal stalls. This landscape and its tasks are an artistic interpretation.")
			spot("ark_wood", "Gather timber", Vector3(-13, 0, 15), "Genesis 6:22", "Help prepare the ark. Gathering timber is an exploration task inspired by Noah's obedience, not a detail stated in this verse.", "timber")
			spot("ark_pairs", "Animal pairs", Vector3(0, 0.3, -8), "Genesis 6:19", "Walk among the paired animals. The stylized models illustrate the story rather than reconstructing every species.")
			for i in range(6):
				cylinder(Vector3(3 + i % 3 * 1.2, 0.5, -23 - i / 3 * 1.2), 0.45, 1, Color("b8a474"))
			spot("ark_food", "Store provisions", Vector3(0, 0.3, -24), "Genesis 6:21", "Read about the food gathered for Noah's family and the animals.", "provisions")
			spot("ark_door", "Ready for the flood", Vector3(0, 0.3, 11), "Genesis 7:7", "Continue to the flood chapter whenever you are ready. You can freely revisit any chapter.", "flood_chapter")
		1:
			ark(true)
			flood = box(Vector3(0, 1.5, 0), Vector3(210, 0.2, 210), Color("437b94"), false)
			flood.material_override = water()
			person(Vector3(4, 7, 8), "Noah", Color("899fbd"))
			spot("flood_rain", "The rain begins", Vector3(0, 7, 9), "Genesis 7:12", "Start a short visual sequence representing the rain and rising waters. The game's short animation does not represent the biblical duration.", "rain")
			spot("flood_waters", "Above the waters", Vector3(-6, 7, -2), "Genesis 7:18", "The ark goes upon the face of the waters. Observe the surrounding mountains from the deck.")
			spot("flood_rest", "The ark rests", Vector3(0, 7, -16), "Genesis 8:4", "The scriptural location is the mountains of Ararat. The mountains around this scene are symbolic scenery.")
			spot("flood_dove", "The returning dove", Vector3(5, 7, -24), "Genesis 8:11", "A dove and an olive leaf mark a change in the story.", "dove")
			spot("flood_covenant", "The covenant", Vector3(-6, 7, -26), "Genesis 9:13", "Reveal a colored bow above the ark and read the sign of the covenant.", "rainbow")
			make_rain()
		2:
			spawn = Vector3(0, 1, 28)
			for x in [-17, 17]:
				house(Vector3(x, 0, 16), Vector3(9, 3.5, 9), Color("ccb994"))
			person(Vector3(-12, 0, 18), "Joseph", Color("9366b8"))
			for i in range(10):
				animal(Vector3(-20 + i * 3, 0, -24), Color("ded2b4"), "Sheep")
			cylinder(Vector3(12, 0.3, -4), 3.3, 0.6, Color("81755f"))
			cylinder(Vector3(12, 0.65, -4), 2.2, 0.12, Color("292d36"))
			for i in range(5):
				person(Vector3(-5 + i * 2.5, 0, -37), "", Color("a1714d"))
			spot("j_coat", "Joseph's coat", Vector3(-10, 0, 18), "Genesis 37:3", "Begin Joseph's story with his father's love and the coat of many colours.")
			spot("j_dream", "The dream", Vector3(13, 0, 18), "Genesis 37:7", "Read Joseph's dream of the sheaves. The floating sheaves are a visual illustration.", "dream")
			spot("j_pit", "The empty pit", Vector3(8, 0, -4), "Genesis 37:24", "Joseph is cast into a pit. The pit here is a safe symbolic viewing point; you do not fall into it.")
			spot("j_caravan", "The caravan", Vector3(0, 0, -34), "Genesis 37:28", "Follow the story's movement toward Egypt.")
			spot("j_egypt", "Journey to Egypt", Vector3(0, 0, -43), "Genesis 39:2", "Enter the Egypt chapter to explore Joseph's hardship, preparation and reconciliation.", "egypt_chapter")
		3:
			spawn = Vector3(0, 1, 35)
			for side in [-1, 1]:
				for i in range(5):
					cylinder(Vector3(side * 12, 4, 14 - i * 8), 0.9, 8, Color("d5bd89"))
					cylinder(Vector3(side * 12, 7.9, 14 - i * 8), 1.3, 0.4, Color("b8965b"))
			house(Vector3(0, 0, -28), Vector3(22, 9, 18), Color("d4bb86"))
			box(Vector3(0, 1, -32), Vector3(3, 2, 1.5), Color("b29750"))
			person(Vector3(0, 2, -32), "Pharaoh", Color("e3c05f"))
			house(Vector3(-27, 0, 1), Vector3(13, 4, 13), Color("a89b80"))
			for i in range(6):
				box(Vector3(-32 + i * 2, 2, 7.5), Vector3(0.1, 4, 0.1), Color("575958"))
			house(Vector3(29, 0, 1), Vector3(15, 5, 16), Color("c7aa73"))
			for x in range(4):
				for z in range(4):
					cylinder(Vector3(25 + x * 2, 0.6, -4 + z * 2), 0.6, 1.2, Color("c2ae85"), 0.35)
			person(Vector3(8, 0, 22), "Joseph", Color("788dad"))
			for i in range(5):
				person(Vector3(19 + i * 2, 0, 22), "", Color("8d7664"))
			spot("e_prison", "The prison", Vector3(-27, 0, 5), "Genesis 39:21", "Read how the LORD was with Joseph during imprisonment.")
			spot("e_pharaoh", "Pharaoh's dreams", Vector3(0, 0, -23), "Genesis 41:16", "Joseph points beyond himself when Pharaoh seeks an answer.")
			spot("e_grain", "Prepare the storehouses", Vector3(29, 0, 6), "Genesis 41:49", "Gather three glowing grain tokens around the storehouse. This task illustrates preparation for the famine.", "grain")
			spot("e_family", "Joseph's brothers", Vector3(21, 0, 24), "Genesis 45:5", "Read Joseph's words to his brothers and consider how the story moves toward reconciliation.", "share")
			spot("e_mercy", "A different ending", Vector3(8, 0, 24), "Genesis 50:20", "Joseph's story includes suffering and mercy. This verse looks back on what happened.")
			for i in range(3):
				spot("grain_" + str(i), "Grain " + str(i + 1), Vector3(21 + i * 8, 0, -12), "Genesis 41:48", "Collect a grain token for the storehouse exploration task.", "collect")
			for i in range(3):
				cylinder(Vector3(-50 + i * 35, 7, -62), 13, 14, Color("cbb07a"), 0)
		4:
			spawn = Vector3(0, 1, 28)
			person(Vector3(7, 0, 15), "Moses", Color("b9a27f"))
			for i in range(9):
				animal(Vector3(-20 + i * 3, 0, 20), Color("ddd3b8"), "Sheep")
			flame = Node3D.new()
			flame.position = Vector3(0, 0, -7)
			add_child(flame)
			for i in range(14):
				var p := Vector3(rng.randf_range(-1.1, 1.1), rng.randf_range(0.5, 2.4), rng.randf_range(-0.8, 0.8))
				var f := sphere(p, rng.randf_range(0.22, 0.48), Color("ffad48"), flame)
				f.material_override = material(Color("ff9d38"), 2)
			var firelight := OmniLight3D.new()
			firelight.position = Vector3(0, 2, -7)
			firelight.light_color = Color("ffa759")
			firelight.omni_range = 15
			firelight.light_energy = 2
			add_child(firelight)
			tree(Vector3(0, 0, -7))
			spot("m_shepherd", "The shepherd", Vector3(7, 0, 18), "Exodus 3:1", "Moses keeps the flock and comes to the mountain of God, Horeb.")
			spot("m_bush", "The burning bush", Vector3(0, 0, -3), "Exodus 3:2", "Observe the flame and read the account of the bush that was not consumed.")
			spot("m_ground", "Holy ground", Vector3(-6, 0, -8), "Exodus 3:5", "Pause at the edge of the bush and read the command given to Moses.")
			spot("m_call", "The call", Vector3(6, 0, -12), "Exodus 3:10", "Read Moses' commission to bring the children of Israel out of Egypt.")
			spot("m_exodus", "Toward the sea", Vector3(0, 0, -29), "Exodus 13:21", "Continue to the Red Sea chapter.", "sea_chapter")
		5:
			spawn = Vector3(0, 1, 43)
			sea_left = box(Vector3(-19, 1.1, -12), Vector3(22, 2.2, 66), Color("427c96"))
			sea_right = box(Vector3(19, 1.1, -12), Vector3(22, 2.2, 66), Color("427c96"))
			sea_middle = box(Vector3(0, 1, -12), Vector3(16, 2, 66), Color("427c96"))
			sea_left.material_override = water()
			sea_right.material_override = water()
			sea_middle.material_override = water()
			person(Vector3(5, 0, 34), "Moses", Color("b9a27f"))
			for i in range(18):
				person(Vector3(-18 + i % 6 * 3, 0, 40 + i / 6 * 4), "", Color.from_hsv(float(i) / 18, 0.22, 0.75))
			spot("s_fear", "Before the sea", Vector3(-6, 0, 35), "Exodus 14:13", "Read Moses' words before the crossing.")
			spot("s_part", "Stretch out the hand", Vector3(5, 0, 31), "Exodus 14:21", "Activate the visual sea-parting sequence. Then walk the dry corridor between the walls of water.", "part")
			spot("s_path", "The dry path", Vector3(0, 0, -6), "Exodus 14:22", "Walk between the two water walls. The dimensions and timing of this scene are artistic choices.")
			spot("s_far", "The far shore", Vector3(0, 0, -51), "Exodus 14:30", "Reach the far shore and read the conclusion of the deliverance account.")
			spot("s_song", "The song", Vector3(5, 0, -59), "Exodus 15:2", "Read the song of praise, then continue toward Sinai.", "sinai_chapter")
		6:
			spawn = Vector3(0, 1, 30)
			for i in range(9):
				var p := Vector3(-30 + i % 3 * 9, 0, -5 + i / 3 * 10)
				house(p, Vector3(5, 2.5, 5), Color("b89473"))
			cylinder(Vector3(0, 14, -42), 25, 28, Color("756d62"), 2)
			var ramp := box(Vector3(0, 1.2, -13), Vector3(9, 0.3, 22), Color("a5947c"))
			ramp.rotation.x = 0.115
			for side in [-1, 1]:
				var tablet := box(Vector3(side * 1.1, 3.6, -22), Vector3(1.6, 2.5, 0.4), Color("c2b79b"))
				tablet.rotation.z = side * -0.07
				for i in range(5):
					box(Vector3(side * 1.1, 4.3 - i * 0.34, -21.77), Vector3(1.05, 0.045, 0.02), Color("6e6658"), false)
			spot("t_arrive", "At Sinai", Vector3(-7, 0, 23), "Exodus 19:2", "The people encamp before the mount.")
			spot("t_covenant", "A covenant", Vector3(8, 0, 12), "Exodus 19:5", "Read the call to obey God's voice and keep his covenant.")
			spot("t_first", "The first commandment", Vector3(0, 2.8, -19), "Exodus 20:3", "The tablets here are a symbolic display at the foot of the mountain. Open the Bible reader for all of Exodus 20.")
			spot("t_rest", "Remember the sabbath", Vector3(-6, 0, -12), "Exodus 20:8", "Read the command concerning the sabbath day.")
			spot("t_honour", "Honour and community", Vector3(8, 0, -11), "Exodus 20:12", "Read the command to honour father and mother. Continue exploring or open the full KJV reader.")
		7:
			spawn = Vector3(0, 1, 36)
			for side in [-1, 1]:
				for i in range(5):
					house(Vector3(side * 32, 0, 22 - i * 9), Vector3(6, 2.8, 5), Color("b69372") if side < 0 else Color("85909a"))
					person(Vector3(side * 27, 0, 22 - i * 9), "", Color("8d795d") if side < 0 else Color("768894"))
			var brook := box(Vector3(-11, 0.04, 3), Vector3(7, 0.08, 64), Color("437b94"), false)
			brook.material_override = water()
			for i in range(5):
				var stone := sphere(Vector3(-7, 0.18, 19 - i * 6), 0.25, Color("c3c2b3"))
				stone.name = "Stone" + str(i)
				spot("d_stone_" + str(i), "Smooth stone " + str(i + 1), Vector3(-5, 0, 19 - i * 6), "1 Samuel 17:40", "Collect one of five smooth stones beside the brook. This gentle task illustrates preparation from the account.", "stone_" + str(i))
			person(Vector3(5, 0, 30), "David", Color("b88968"))
			var giant := Node3D.new()
			giant.name = "Goliath"
			giant.position = Vector3(0, 0, -29)
			giant.scale = Vector3.ONE * 2.7
			add_child(giant)
			person(Vector3.ZERO, "", Color("647b84"), giant)
			box(Vector3(0, 1.1, -0.28), Vector3(0.58, 0.9, 0.16), Color("8d9da4"), false, giant)
			cylinder(Vector3(0.64, 1.05, 0), 0.055, 2.8, Color("5d4939"), 0.055, giant)
			box(Vector3(-0.55, 1, -0.25), Vector3(0.5, 1, 0.1), Color("9da491"), false, giant)
			label_at(Vector3(0, 6.7, -29), "Goliath", 28)
			spot("d_meet", "David's courage", Vector3(5, 0, 32), "1 Samuel 17:37", "Meet David, explore the two camps and gather five smooth stones. The confrontation is shown without graphic violence.")
			spot("d_encounter", "The confrontation", Vector3(0, 0, -16), "1 Samuel 17:45", "After collecting five stones, begin a short sling-and-stone illustration of the account.", "david_event")
			spot("d_victory", "The stone and the sling", Vector3(10, 0, -33), "1 Samuel 17:50", "Read the outcome described by the KJV. The stylized animation is a visual summary, not a combat simulation.")
		8:
			spawn = Vector3(0, 1, 29)
			var stone_color := Color("7e7c87")
			for i in range(22):
				var a := i * TAU / 24.0
				var wall := box(Vector3(sin(a) * 15, 3.5, -6 + cos(a) * 15), Vector3(4, 7, 1.1), stone_color)
				wall.rotation.y = a
			# Opening in the south-east arc; the front passage remains open for walking.
			for child in get_children():
				if child is MeshInstance3D and child.position.z > 7 and absf(child.position.x) < 5 and child.position.y > 1:
					child.queue_free()
			for i in range(6):
				cylinder(Vector3(-12 + i * 5, 4.2, -19), 0.45, 8.4, Color("aaa28e"))
			person(Vector3(0, 0, -7), "Daniel", Color("7a8fa9"))
			var lions := Node3D.new()
			lions.name = "Lions"
			add_child(lions)
			for i in range(4):
				var lion := Node3D.new()
				lion.position = Vector3(-9 + i * 6, 0, -12 if i % 2 == 0 else 0)
				lions.add_child(lion)
				sphere(Vector3(0, 0.8, 0), 0.75, Color("b38a4e"), lion).scale = Vector3(0.7, 0.7, 1.6)
				sphere(Vector3(0, 1.05, -1), 0.5, Color("826238"), lion)
				sphere(Vector3(0, 1.04, -1.3), 0.3, Color("c49a5f"), lion)
				for side in [-1, 1]:
					for z in [-0.6, 0.6]:
						cylinder(Vector3(side * 0.3, 0.35, z), 0.11, 0.7, Color("b38a4e"), 0.11, lion)
			person(Vector3(7, 0, 24), "King Darius", Color("a99a6a"))
			spot("dan_decree", "The decree", Vector3(7, 0, 26), "Daniel 6:7", "Read the decree, then explore the den and Daniel's response. The player can enter and leave safely.")
			spot("dan_prayer", "Daniel's prayer", Vector3(0, 0, -4), "Daniel 6:10", "Read Daniel's pattern of prayer. Activate a quiet visual moment; this is a reflection task, not a prayer score.", "daniel_pray")
			spot("dan_lions", "The lions' den", Vector3(-8, 0, 2), "Daniel 6:16", "Observe the stylized lions. They do not attack the player.")
			spot("dan_angel", "The lions' mouths", Vector3(8, 0, -11), "Daniel 6:22", "After the prayer moment, see the lions settle and a symbolic shaft of light appear.", "daniel_peace")
			spot("dan_dawn", "At the break of day", Vector3(0, 0, 16), "Daniel 6:19", "Bring daylight to the scene and read the king's early visit.", "daniel_dawn")
			spot("dan_trust", "Delivered", Vector3(-7, 0, 25), "Daniel 6:23", "Read the account's conclusion and compare it with the events that came before.")
		9:
			spawn = Vector3(-24, 1, 31)
			var coast := box(Vector3(-51, -0.02, -12), Vector3(60, 0.12, 120), Color("437b94"), false)
			coast.material_override = water()
			# The walkable ship is beside the shore: its deck is level with the pier.
			box(Vector3(-24, 0.04, 2), Vector3(8, 0.08, 55), Color("8b6845"))
			for side in [-1, 1]:
				box(Vector3(-24 + side * 4, 1.1, -10), Vector3(0.35, 2.2, 22), Color("805a3b"))
			cylinder(Vector3(-24, 6, -9), 0.18, 12, Color("654d38"))
			box(Vector3(-24, 7, -9), Vector3(7, 5, 0.08), Color("e0cfaa"), false)
			person(Vector3(-24, 0, 22), "Jonah", Color("839aab"))
			for i in range(3):
				person(Vector3(-26 + i * 2, 0, -15), "Sailor" if i == 0 else "", Color("b6a084"))
			# A symbolic great-fish chamber: visible ribs and a safe open entrance.
			var fish := sphere(Vector3(28, 3.2, -7), 4.6, Color("566d83"))
			fish.scale = Vector3(1.6, 1, 3.4)
			for side in [-1, 1]:
				box(Vector3(28 + side * 3.2, 2, -8), Vector3(0.6, 4, 24), Color("74636a"))
			box(Vector3(28, 4.2, -8), Vector3(7, 0.5, 24), Color("655864"))
			for i in range(9):
				for side in [-1, 1]:
					var rib := box(Vector3(28 + side * 2.8, 2, 3 - i * 2.6), Vector3(0.15, 3.9, 0.24), Color("a18c83"), false)
					rib.rotation.z = side * 0.1
				box(Vector3(28, 3.9, 3 - i * 2.6), Vector3(5.5, 0.18, 0.24), Color("a18c83"), false)
			var light := OmniLight3D.new()
			light.position = Vector3(28, 2, -5)
			light.light_color = Color("b9d4e0")
			light.light_energy = 1.2
			light.omni_range = 18
			add_child(light)
			for i in range(5):
				house(Vector3(-12 + i * 6, 0, -52), Vector3(5, 5 + i % 2, 7), Color("c3ad85"))
				person(Vector3(-12 + i * 6, 0, -44), "", Color("9a8973"))
			spot("jon_call", "The call to Nineveh", Vector3(-24, 0, 25), "Jonah 1:2", "Start at the harbour. Explore the ship, the symbolic great-fish chamber, and the city gate.")
			spot("jon_storm", "A mighty tempest", Vector3(-24, 0, -8), "Jonah 1:4", "Start a short storm illustration. The ship remains safe to walk; this is a gentle exploration scene.", "jonah_storm")
			spot("jon_fish", "The great fish", Vector3(28, 0, 7), "Jonah 1:17", "Enter the chamber through the south entrance. Its ribs and size are an artistic space, not an anatomical reconstruction.")
			spot("jon_prayer", "Out of the fish's belly", Vector3(28, 0, -8), "Jonah 2:1", "Read Jonah's prayer and reveal a calm light inside the chamber.", "jonah_pray")
			spot("jon_shore", "The second call", Vector3(8, 0, -28), "Jonah 3:2", "Read the renewed call and walk toward the buildings of Nineveh.")
			spot("jon_city", "Nineveh", Vector3(0, 0, -42), "Jonah 3:10", "Read the city's response and then open Jonah 4 to explore the story's final conversation.", "jonah_mercy")
	# Invisible boundary walls prevent leaving the playable world.
	for side in [-1, 1]:
		var wall := box(Vector3(side * 108, 6, 0), Vector3(1, 30, 220), Color.WHITE)
		wall.visible = false
		wall = box(Vector3(0, 6, side * 108), Vector3(220, 30, 1), Color.WHITE)
		wall.visible = false

func make_rain() -> void:
	rain = MultiMeshInstance3D.new()
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	var mesh := BoxMesh.new()
	mesh.size = Vector3(0.025, 0.8, 0.025)
	mm.mesh = mesh
	mm.instance_count = 400
	for i in range(400):
		mm.set_instance_transform(i, Transform3D(Basis.IDENTITY, Vector3(rng.randf_range(-28, 28), rng.randf_range(9, 36), rng.randf_range(-40, 25))))
	rain.multimesh = mm
	rain.material_override = material(Color("afcddd"))
	rain.visible = false
	add_child(rain)

func trigger(action: String) -> void:
	if action.begins_with("stone_"):
		var id := "d_stone_" + action.get_slice("_", 1)
		for s in spots:
			if s.id == id:
				s.marker.material_override = material(Color("7fbf96"), 0.6)
		var stone_node := get_node_or_null("Stone" + action.get_slice("_", 1))
		if stone_node != null:
			stone_node.hide()
		return
	if action.begins_with("collect_"):
		var id := "grain_" + action.get_slice("_", 1)
		for s in spots:
			if s.id == id:
				s.marker.material_override = material(Color("7fbf96"), 0.6)
		return
	match action:
		"part":
			if event_started:
				return
			event_started = true
			# Remove the blocking middle collision immediately; the player waits during the cinematic.
			sea_middle.get_child(0).queue_free()
			var tw := create_tween().set_parallel(true)
			tw.tween_property(sea_middle, "position:y", -2.0, 5.0)
			tw.tween_property(sea_left, "scale:y", 6.0, 5.0).set_trans(Tween.TRANS_SINE)
			tw.tween_property(sea_right, "scale:y", 6.0, 5.0).set_trans(Tween.TRANS_SINE)
			tw.tween_property(sea_left, "position:y", 6.6, 5.0)
			tw.tween_property(sea_right, "position:y", 6.6, 5.0)
		"rain":
			if event_started:
				return
			event_started = true
			rain.visible = true
			create_tween().tween_property(flood, "position:y", 5.2, 10.0)
		"rainbow":
			if has_node("Rainbow"):
				return
			var arc := Node3D.new()
			arc.name = "Rainbow"
			add_child(arc)
			for color_index in range(7):
				for i in range(48):
					var a := float(i) / 47 * PI
					var r := 21.0 + color_index * 0.45
					sphere(Vector3(cos(a) * r, 10 + sin(a) * r, -53), 0.38, Color.from_hsv(float(color_index) / 8, 0.62, 0.95), arc)
		"dove":
			if has_node("Dove"):
				return
			var dove := Node3D.new()
			dove.name = "Dove"
			add_child(dove)
			sphere(Vector3.ZERO, 0.3, Color("eee8d3"), dove)
			for side in [-1, 1]:
				box(Vector3(side * 0.5, 0, 0), Vector3(0.9, 0.06, 0.4), Color("fff6e2"), false, dove).rotation.z = side * 0.22
			dove.position = Vector3(-25, 14, -40)
			create_tween().tween_property(dove, "position", Vector3(5, 9, -24), 6.0)
		"dream":
			if has_node("Dream"):
				return
			var dream := Node3D.new()
			dream.name = "Dream"
			add_child(dream)
			for i in range(12):
				var a := i * TAU / 12
				cylinder(Vector3(13 + cos(a) * 3, 2, 18 + sin(a) * 3), 0.16, 1.4, Color("e4c46e"), 0.16, dream)
		"david_event":
			if event_started:
				return
			event_started = true
			var giant := get_node("Goliath")
			var pebble := sphere(Vector3(0, 1.5, -14), 0.18, Color("d2ccba"))
			var tw := create_tween()
			tw.tween_property(pebble, "position", Vector3(0, 4.4, -29), 1.1)
			tw.tween_property(giant, "rotation:z", -PI / 2, 1.6).set_trans(Tween.TRANS_SINE)
			tw.tween_callback(pebble.queue_free)
		"daniel_pray":
			if not has_node("PrayerLight"):
				var light := OmniLight3D.new()
				light.name = "PrayerLight"
				light.position = Vector3(0, 4, -7)
				light.light_color = Color("f2d8a6")
				light.light_energy = 1.5
				light.omni_range = 20
				add_child(light)
		"daniel_peace":
			if has_node("Lions"):
				for lion in get_node("Lions").get_children():
					create_tween().tween_property(lion, "scale:y", 0.6, 1.8)
		"jonah_storm":
			if not is_instance_valid(rain):
				make_rain()
			rain.position.x = -24
			rain.visible = true
		"jonah_pray":
			if is_instance_valid(rain):
				rain.visible = false
			if not has_node("CalmLight"):
				var light := OmniLight3D.new()
				light.name = "CalmLight"
				light.position = Vector3(28, 3, -8)
				light.light_color = Color("ffe1a1")
				light.light_energy = 1.8
				light.omni_range = 17
				add_child(light)
		"jonah_mercy":
			if not has_node("CityWelcome"):
				var folk := Node3D.new()
				folk.name = "CityWelcome"
				add_child(folk)
				for i in range(8):
					person(Vector3(-10 + i * 3, 0, -36), "", Color("b4aa8e"), folk)
		"timber":
			if has_node("Timber"):
				get_node("Timber").queue_free()
			if not has_node("StoredTimber"):
				var stored := Node3D.new()
				stored.name = "StoredTimber"
				add_child(stored)
				for i in range(8):
					box(Vector3(6, 0.2 + i * 0.2, 8), Vector3(5, 0.18, 0.5), Color("9a714a"), false, stored)
		"provisions":
			if not has_node("StoredFood"):
				var food := Node3D.new()
				food.name = "StoredFood"
				add_child(food)
				for i in range(6):
					cylinder(Vector3(-5 - i % 3, 0.55, -23 - i / 3), 0.4, 1.1, Color("d5b97b"), 0.25, food)
		"share":
			if not has_node("SharedGrain"):
				var grain := Node3D.new()
				grain.name = "SharedGrain"
				add_child(grain)
				for i in range(5):
					cylinder(Vector3(19 + i * 2, 0.45, 24), 0.4, 0.9, Color("d5b97b"), 0.2, grain)

func restore_events(actions: Array) -> void:
	for action in actions:
		if chapter == 5 and action == "part":
			event_started = true
			sea_middle.get_child(0).queue_free()
		elif chapter == 7 and action == "david_event":
			event_started = true
			get_node("Goliath").rotation.z = -PI / 2
		elif chapter == 8 and action == "daniel_peace":
			for lion in get_node("Lions").get_children():
				lion.scale.y = 0.6
		elif chapter == 1 and action == "rain":
			event_started = true
			rain.visible = true
		else:
			trigger(str(action))
	# Snap persistent environment events to their completed state on return.
	if chapter == 5 and actions.has("part"):
		sea_middle.position.y = -2
		sea_left.scale.y = 6
		sea_right.scale.y = 6
		sea_left.position.y = 6.6
		sea_right.position.y = 6.6
	if chapter == 1 and actions.has("rain"):
		flood.position.y = 5.2

func _process(delta: float) -> void:
	time += delta
	for gem in animated:
		gem.rotation.y += delta
		gem.position.y += sin(time * 2 + gem.position.x) * delta * 0.08
	if is_instance_valid(flame):
		flame.scale = Vector3(1 + sin(time * 4) * 0.08, 1 + sin(time * 7) * 0.1, 1)
	if is_instance_valid(rain) and rain.visible:
		rain.position.y = -fmod(time * 15, 20)
	if is_instance_valid(flood) and event_started:
		flood.rotation.z = sin(time * 0.45) * 0.002

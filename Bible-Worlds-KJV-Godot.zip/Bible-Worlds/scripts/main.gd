extends Node3D

const WorldScript = preload("res://scripts/world.gd")
const PlayerScript = preload("res://scripts/player.gd")
const MapScript = preload("res://scripts/map.gd")
const SAVE_PATH := "user://bible_worlds_save.json"
const CHAPTERS := [
	["Noah • The Ark", "Walk the ark's aisle, meet Noah, and prepare supplies.", "Genesis 6–7"],
	["Noah • Above the Waters", "Stand on the ark's deck, begin the rain, and reveal the covenant bow.", "Genesis 7–9"],
	["Joseph • Canaan", "Explore the camp, Joseph's dream, the pit, and the caravan route.", "Genesis 37–39"],
	["Joseph • Egypt", "Visit the palace, prison and granary; collect grain and meet the brothers.", "Genesis 39–50"],
	["Moses • The Burning Bush", "Walk the shepherd's wilderness and discover the call at Horeb.", "Exodus 3; 13"],
	["Moses • The Red Sea", "Part the waters and walk the dry path to the far shore.", "Exodus 14–15"],
	["Moses • Mount Sinai", "Explore the camp and the covenant; read the commandments.", "Exodus 19–20"],
	["David • The Valley of Elah", "Gather five smooth stones and witness the confrontation with Goliath.", "1 Samuel 17"],
	["Daniel • The Lions' Den", "Explore the den, reflect on prayer, and witness the break of day.", "Daniel 6"],
	["Jonah • The Sea and Nineveh", "Walk the ship, enter the great-fish chamber and visit Nineveh.", "Jonah 1–4"]
]
var world: Node3D
var player: CharacterBody3D
var environment: WorldEnvironment
var sun: DirectionalLight3D
var bible: Array = []
var seen: Dictionary = {}
var actions: Dictionary = {}
var current_chapter := 0
var modal: PanelContainer
var modal_content: VBoxContainer
var hud: VBoxContainer
var title_label: Label
var objective_label: Label
var prompt: Label
var compass: Label
var crosshair: Label
var toast: Label
var nearest: Dictionary = {}
var autosave_time := 0.0
var toast_time := 0.0
var clock := 0.0
var cinematic := 0.0
var initial_loading := false
var bible_book := 0
var bible_chapter := 0
var reader_text: RichTextLabel
var reader_book: OptionButton
var reader_chapter: OptionButton
var search_box: LineEdit
var menu_view := ""
var quality_low := false
var save_data: Dictionary = {}
var chapter_locations: Dictionary = {}
var waypoint_id := ""
var cinematic_message := ""
var ambience: AudioStreamPlayer
var rain_sound: AudioStreamPlayer

func _ready() -> void:
	get_tree().auto_accept_quit = false
	setup_input()
	load_bible()
	load_save()
	setup_environment()
	setup_ui()
	setup_audio()
	load_chapter(current_chapter, true)
	show_home()
	if OS.get_cmdline_user_args().has("--smoke-test"):
		call_deferred("smoke_test")

func setup_input() -> void:
	var keys := {"forward": [KEY_W, KEY_UP], "back": [KEY_S, KEY_DOWN], "left": [KEY_A, KEY_LEFT], "right": [KEY_D, KEY_RIGHT], "sprint": [KEY_SHIFT], "jump": [KEY_SPACE], "interact": [KEY_E], "chapters": [KEY_M], "journal": [KEY_J], "bible": [KEY_B], "rescue": [KEY_R], "map": [KEY_TAB], "objectives": [KEY_Q]}
	for action in keys:
		InputMap.add_action(action)
		for key in keys[action]:
			var ev := InputEventKey.new()
			ev.physical_keycode = key
			InputMap.action_add_event(action, ev)

func load_bible() -> void:
	var raw = JSON.parse_string(FileAccess.get_file_as_string("res://data/kjv.json"))
	if raw is Array:
		bible = raw

func passage(ref: String) -> String:
	var space := ref.rfind(" ")
	if space < 0:
		return ""
	var book_name := ref.substr(0, space)
	var cv := ref.substr(space + 1).split(":")
	if cv.size() != 2:
		return ""
	for book in bible:
		if str(book.book).replace(" ", "").to_lower() == book_name.replace(" ", "").to_lower():
			var chapters: Array = book.chapters
			var c := int(cv[0]) - 1
			if c < 0 or c >= chapters.size():
				return ""
			for verse in chapters[c].verses:
				if int(verse.verse) == int(cv[1]):
					return str(verse.text)
	return ""

func setup_environment() -> void:
	environment = WorldEnvironment.new()
	var env := Environment.new()
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color("355f80")
	sky_mat.sky_horizon_color = Color("a6bdc1")
	sky_mat.ground_bottom_color = Color("5d645d")
	sky_mat.ground_horizon_color = Color("a6bdc1")
	sky.sky_material = sky_mat
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("d0dbdd")
	env.ambient_light_energy = 0.3
	env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	env.fog_enabled = true
	env.fog_density = 0.0025
	env.fog_light_color = Color("b9b6a0")
	environment.environment = env
	add_child(environment)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-34, -32, 0)
	sun.light_color = Color("ffe3ac")
	sun.light_energy = 0.85
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 70
	add_child(sun)
	player = PlayerScript.new()
	add_child(player)

func setup_audio() -> void:
	ambience = AudioStreamPlayer.new()
	ambience.stream = load("res://audio/wind.wav")
	ambience.stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	ambience.stream.loop_end = int(ambience.stream.get_length() * ambience.stream.mix_rate)
	ambience.volume_db = -24
	add_child(ambience)
	ambience.play()
	rain_sound = AudioStreamPlayer.new()
	rain_sound.stream = load("res://audio/rain.wav")
	rain_sound.stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	rain_sound.stream.loop_end = int(rain_sound.stream.get_length() * rain_sound.stream.mix_rate)
	rain_sound.volume_db = -18
	add_child(rain_sound)

func style(color: Color, border: Color = Color("78664b")) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = color
	s.border_color = border
	s.set_border_width_all(1)
	s.set_corner_radius_all(10)
	s.content_margin_left = 20
	s.content_margin_right = 20
	s.content_margin_top = 14
	s.content_margin_bottom = 14
	return s

func setup_ui() -> void:
	var canvas := CanvasLayer.new()
	add_child(canvas)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	canvas.add_child(root)
	var theme := Theme.new()
	theme.default_font_size = 18
	theme.set_color("font_color", "Label", Color("eee4cf"))
	theme.set_color("font_color", "Button", Color("f2e4c6"))
	theme.set_stylebox("normal", "Button", style(Color("263b46")))
	theme.set_stylebox("hover", "Button", style(Color("3e5661"), Color("e9c981")))
	theme.set_stylebox("pressed", "Button", style(Color("1f3038")))
	theme.set_stylebox("focus", "Button", style(Color(0, 0, 0, 0), Color("eed4a0")))
	root.theme = theme
	var top := PanelContainer.new()
	top.position = Vector2(18, 16)
	top.custom_minimum_size = Vector2(520, 100)
	top.add_theme_stylebox_override("panel", style(Color(0.055, 0.09, 0.115, 0.87)))
	root.add_child(top)
	hud = VBoxContainer.new()
	top.add_child(hud)
	title_label = text_label("", 24)
	hud.add_child(title_label)
	objective_label = text_label("", 16)
	hud.add_child(objective_label)
	compass = text_label("", 15)
	hud.add_child(compass)
	var help := text_label("WASD / arrows  Walk    Mouse  Look    E  Interact    Shift  Run\nM  Chapters    J  Journal    B  Bible    Tab  Map    Q  Objectives    R  Return    Esc  Menu", 15)
	help.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	help.offset_left = 20
	help.offset_top = -64
	help.offset_right = 820
	help.offset_bottom = -16
	help.add_theme_color_override("font_outline_color", Color("0d1a22"))
	help.add_theme_constant_override("outline_size", 5)
	root.add_child(help)
	crosshair = text_label("·", 38)
	crosshair.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	crosshair.offset_left = -10
	crosshair.offset_top = -28
	root.add_child(crosshair)
	prompt = text_label("", 20)
	prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prompt.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	prompt.offset_left = -370
	prompt.offset_right = 370
	prompt.offset_top = -125
	prompt.offset_bottom = -82
	prompt.add_theme_color_override("font_outline_color", Color("0d1a22"))
	prompt.add_theme_constant_override("outline_size", 6)
	root.add_child(prompt)
	toast = text_label("", 22)
	toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	toast.offset_left = -400
	toast.offset_right = 400
	toast.offset_top = 22
	toast.offset_bottom = 60
	root.add_child(toast)
	modal = PanelContainer.new()
	modal.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	modal.offset_left = 70
	modal.offset_right = -70
	modal.offset_top = 35
	modal.offset_bottom = -35
	modal.add_theme_stylebox_override("panel", style(Color("101e29"), Color("ad8c58")))
	root.add_child(modal)
	modal_content = VBoxContainer.new()
	modal_content.add_theme_constant_override("separation", 12)
	modal.add_child(modal_content)

func text_label(text: String, font_size: int = 18) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_size)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func button(text: String, callback: Callable, parent: Node = modal_content) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size.y = 44
	b.pressed.connect(callback)
	parent.add_child(b)
	return b

func clear_modal(title: String, subtitle: String = "") -> void:
	for child in modal_content.get_children():
		modal_content.remove_child(child)
		child.queue_free()
	modal.show()
	player.active = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	crosshair.hide()
	var heading := HBoxContainer.new()
	modal_content.add_child(heading)
	var l := text_label(title, 30)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	heading.add_child(l)
	button("Return to world", close_modal, heading)
	if not subtitle.is_empty():
		var sub := text_label(subtitle, 16)
		sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		modal_content.add_child(sub)

func scroll_column() -> VBoxContainer:
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	modal_content.add_child(sc)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 10)
	sc.add_child(col)
	return col

func rich(text: String, parent: Node) -> RichTextLabel:
	var r := RichTextLabel.new()
	r.bbcode_enabled = true
	r.text = text
	r.fit_content = true
	r.scroll_active = false
	r.add_theme_font_size_override("normal_font_size", 20)
	r.add_theme_color_override("default_color", Color("e6dec9"))
	parent.add_child(r)
	return r

func close_modal() -> void:
	modal.hide()
	player.active = true
	crosshair.show()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	menu_view = ""

func show_home() -> void:
	menu_view = "home"
	clear_modal("BIBLE WORLDS", "KJV EXPLORER  •  A peaceful 3D journey through ten story chapters")
	var col := scroll_column()
	rich("[font_size=27][color=#e8c788]Walk into the story.[/color][/font_size]\n\nExplore the ark, the Egyptian storehouses and the wilderness. Read scripture at golden discovery markers. Trigger the rain, reveal the covenant bow and walk between the parted waters.\n\nEvery chapter is available from the start. Discoveries and your last position save automatically. The full 66-book KJV reader works offline.\n\n[color=#acbfc8]The scenery, character designs and exploration tasks are artistic interpretations. Scripture panels quote the KJV text and give the reference.[/color]", col)
	button("Continue exploring  •  " + CHAPTERS[current_chapter][0], close_modal, col)
	button("Choose a story chapter", show_chapters, col)
	button("Open the complete KJV Bible", show_reader, col)
	button("Chapter map & destinations", show_map, col)
	button("Journey objectives", show_objectives, col)
	button("Passage journal", show_journal, col)
	button("Settings & controls", show_settings, col)
	button("Save and quit", quit_game, col)

func show_chapters() -> void:
	menu_view = "chapters"
	clear_modal("Story chapters", "Choose any chapter. Each chapter remembers completed discoveries and events.")
	var col := scroll_column()
	for i in range(CHAPTERS.size()):
		var panel := VBoxContainer.new()
		col.add_child(panel)
		button(str(i + 1) + "  •  " + CHAPTERS[i][0] + "    [" + str(chapter_count(i)) + " discoveries]" + ("  ✓" if chapter_complete(i) else ""), enter_chapter.bind(i), panel)
		var l := text_label(CHAPTERS[i][1] + "  |  " + CHAPTERS[i][2], 16)
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		panel.add_child(l)
	button("Main menu", show_home)

func enter_chapter(index: int) -> void:
	save_game()
	load_chapter(index)
	close_modal()
	message("Explore " + CHAPTERS[index][0])

func load_chapter(index: int, restore_position: bool = false) -> void:
	current_chapter = clampi(index, 0, CHAPTERS.size() - 1)
	cinematic = 0
	player.active = false
	if is_instance_valid(world):
		remove_child(world)
		world.queue_free()
	world = WorldScript.new()
	add_child(world)
	world.build(current_chapter)
	player.position = world.spawn
	waypoint_id = ""
	player.rotation = Vector3.ZERO
	player.camera.rotation = Vector3.ZERO
	player.velocity = Vector3.ZERO
	var stored_actions: Array = actions.get(str(current_chapter), [])
	world.restore_events(stored_actions)
	if chapter_locations.has(str(current_chapter)):
		var loc: Dictionary = chapter_locations[str(current_chapter)]
		var lp: Array = loc.get("position", [])
		if lp.size() == 3:
			player.position = Vector3(float(lp[0]), float(lp[1]), float(lp[2]))
			player.rotation.y = float(loc.get("yaw", 0))
			player.camera.rotation.x = float(loc.get("pitch", 0))
	if restore_position and save_data.has("position"):
		var p: Array = save_data.position
		if p.size() == 3 and absf(float(p[0])) < 108 and absf(float(p[2])) < 108 and float(p[1]) > -1 and float(p[1]) < 35:
			player.position = Vector3(float(p[0]), float(p[1]), float(p[2]))
			player.rotation.y = float(save_data.get("yaw", 0))
			player.camera.rotation.x = float(save_data.get("pitch", 0))
	var env: Environment = environment.environment
	var sky_mat: ProceduralSkyMaterial = env.sky.sky_material
	if current_chapter == 1:
		sky_mat.sky_top_color = Color("233c52")
		sky_mat.sky_horizon_color = Color("8d9eaa")
		sun.light_energy = 0.6
	elif current_chapter in [4, 8]:
		sky_mat.sky_top_color = Color("293650")
		sky_mat.sky_horizon_color = Color("bb856e")
		sun.light_energy = 0.55
	else:
		sky_mat.sky_top_color = Color("355f80")
		sky_mat.sky_horizon_color = Color("a6bdc1")
		sun.light_energy = 0.85
	rain_sound.stop()
	if current_chapter == 1 and stored_actions.has("rain"):
		rain_sound.play()
	if current_chapter == 9:
		if stored_actions.has("jonah_storm") and not stored_actions.has("jonah_pray"):
			rain_sound.play()
	if current_chapter == 8 and stored_actions.has("daniel_dawn"):
		sun.light_energy = 0.85
		sky_mat.sky_top_color = Color("355f80")
		sky_mat.sky_horizon_color = Color("a6bdc1")
	nearest = {}
	title_label.text = CHAPTERS[current_chapter][0]
	update_progress()

func update_progress() -> void:
	var count := chapter_count(current_chapter)
	objective_label.text = str(count) + " / " + str(world.spots.size()) + " discoveries   •   Follow the golden markers"
	if count == world.spots.size() and chapter_complete(current_chapter):
		objective_label.text = "Chapter explored  •  M: choose another story  •  B: read more"
	if current_chapter == 3:
		var collected := 0
		var stored: Array = actions.get("3", [])
		for i in range(3):
			if stored.has("collect_" + str(i)):
				collected += 1
		objective_label.text += "  •  Grain " + str(collected) + "/3"
	var next_task := next_objective(current_chapter)
	if not next_task.is_empty():
		objective_label.text += "\nTask: " + next_task

func chapter_count(index: int) -> int:
	var count := 0
	for id in seen:
		if int(seen[id].chapter) == index:
			count += 1
	return count

func message(text: String) -> void:
	toast.text = text
	toast_time = 4.0

func _process(delta: float) -> void:
	clock += delta
	autosave_time += delta
	if autosave_time > 10:
		autosave_time = 0
		save_game()
	if toast_time > 0:
		toast_time -= delta
	else:
		toast.text = ""
	if cinematic > 0:
		cinematic -= delta
		prompt.text = cinematic_message + "  " + str(ceili(cinematic))
		if cinematic <= 0:
			player.active = true
			message("The event is complete. Continue exploring.")
	if not is_instance_valid(world) or modal.visible:
		return
	nearest = {}
	var best := 4.6
	var next_spot: Dictionary = {}
	var next_distance := INF
	for s in world.spots:
		var dist: float = player.position.distance_to(s.pos)
		if dist < best:
			best = dist
			nearest = s
		if not seen.has(s.id) and dist < next_distance:
			next_distance = dist
			next_spot = s
	if cinematic <= 0:
		prompt.text = "[E]  " + str(nearest.title) if not nearest.is_empty() else ""
	if not waypoint_id.is_empty():
		for s in world.spots:
			if s.id == waypoint_id:
				next_spot = s
				next_distance = player.position.distance_to(s.pos)
				if next_distance < 4.6:
					waypoint_id = ""
	if next_spot.is_empty():
		var task := next_objective(current_chapter)
		compass.text = "All discoveries found. Explore freely." if task.is_empty() else "Q: next task  •  " + task
	else:
		var relative: Vector3 = player.global_transform.basis.inverse() * (next_spot.pos - player.position)
		var angle := rad_to_deg(atan2(relative.x, -relative.z))
		var direction := "Ahead" if absf(angle) < 25 else ("Right" if angle > 0 else "Left")
		if absf(angle) > 145:
			direction = "Behind"
		compass.text = direction + "  •  " + str(next_spot.title) + "  •  " + str(roundi(next_distance)) + " m"

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if modal.visible:
			close_modal()
		else:
			show_home()
		get_viewport().set_input_as_handled()
		return
	if modal.visible:
		return
	if event.is_action_pressed("map"):
		show_map()
	elif event.is_action_pressed("objectives"):
		show_objectives()
	elif event.is_action_pressed("chapters"):
		show_chapters()
	elif event.is_action_pressed("journal"):
		show_journal()
	elif event.is_action_pressed("bible"):
		show_reader()
	elif event.is_action_pressed("rescue"):
		rescue()
	elif event.is_action_pressed("interact") and cinematic <= 0 and not nearest.is_empty():
		show_spot(nearest)

func show_spot(s: Dictionary) -> void:
	menu_view = "passage"
	clear_modal(s.title, s.ref + "  •  KING JAMES VERSION")
	var col := scroll_column()
	rich("[font_size=26][color=#f1d49d]“" + passage(s.ref) + "”[/color][/font_size]\n\n[color=#95b1bf]SCENE NOTES[/color]\n" + s.context, col)
	seen[s.id] = {"chapter": current_chapter, "title": s.title, "ref": s.ref, "context": s.context}
	update_progress()
	save_game()
	if not str(s.action).is_empty():
		var action_title := {"timber": "Gather timber", "provisions": "Store provisions", "flood_chapter": "Enter the flood chapter", "rain": "Begin the rain", "dove": "Release the dove animation", "rainbow": "Reveal the covenant bow", "dream": "Illustrate the dream", "egypt_chapter": "Travel to Egypt", "grain": "Check the grain collection", "share": "Share the stored grain", "collect": "Collect this grain", "sea_chapter": "Travel to the Red Sea", "part": "Part the waters", "sinai_chapter": "Travel to Sinai", "david_event": "Begin the sling illustration", "daniel_pray": "Pause for the prayer moment", "daniel_peace": "Let the lions settle", "daniel_dawn": "Bring the dawn", "jonah_storm": "Begin the tempest", "jonah_pray": "Reveal the calm light", "jonah_mercy": "Enter the city response"}
		button("Collect this smooth stone" if str(s.action).begins_with("stone_") else action_title.get(s.action, "Continue"), perform_action.bind(s), col)
	button("Read this chapter in the Bible", open_reference.bind(str(s.ref)), col)
	button("Keep exploring", close_modal, col)

func perform_action(s: Dictionary) -> void:
	var action: String = s.action
	match action:
		"flood_chapter":
			enter_chapter(1)
			return
		"egypt_chapter":
			enter_chapter(3)
			return
		"sea_chapter":
			enter_chapter(5)
			return
		"sinai_chapter":
			enter_chapter(6)
			return
		"grain", "share":
			var collected := 0
			var a: Array = actions.get("3", [])
			for i in range(3):
				if a.has("collect_" + str(i)):
					collected += 1
			if collected < 3:
				close_modal()
				message("Grain collected: " + str(collected) + "/3. Find the three markers behind the storehouse.")
				return
		"collect":
			action = "collect_" + str(s.id).get_slice("_", 1)
	var requirements := {"david_event": ["stone_0", "stone_1", "stone_2", "stone_3", "stone_4"], "daniel_peace": ["daniel_pray"], "daniel_dawn": ["daniel_peace"], "jonah_pray": ["jonah_storm"], "jonah_mercy": ["jonah_pray"]}
	var required: Array = requirements.get(action, [])
	var a: Array = actions.get(str(current_chapter), [])
	for prerequisite in required:
		if not a.has(prerequisite):
			close_modal()
			message("First: " + objective_name(str(prerequisite)) + ". Q opens your task list.")
			return
	var first_completion := not a.has(action)
	if first_completion:
		a.append(action)
		actions[str(current_chapter)] = a
		world.trigger(action)
		message("Completed: " + str(s.title))
	else:
		message("Already completed: " + str(s.title))
	close_modal()
	if action == "part" and first_completion:
		cinematic = 5.2
		cinematic_message = "The waters divide…"
		player.active = false
		player.rotation.y = 0
		player.camera.rotation.x = -0.07
	if action == "david_event" and first_completion:
		cinematic = 3.0
		cinematic_message = "The stone and the sling…"
		player.active = false
		player.camera.look_at(Vector3(0, 4, -29))
	if action in ["rain", "jonah_storm"]:
		rain_sound.play()
	if action == "jonah_pray":
		rain_sound.stop()
	if action == "daniel_dawn":
		sun.light_energy = 0.85
		var sky_mat: ProceduralSkyMaterial = environment.environment.sky.sky_material
		sky_mat.sky_top_color = Color("355f80")
		sky_mat.sky_horizon_color = Color("a6bdc1")
	update_progress()
	save_game()

func show_journal() -> void:
	menu_view = "journal"
	clear_modal("Passage journal", str(seen.size()) + " discoveries saved  •  Scripture and scene notes")
	var col := scroll_column()
	if seen.is_empty():
		rich("Walk to a golden marker and press E to begin your journal.", col)
	for i in range(CHAPTERS.size()):
		if chapter_count(i) == 0:
			continue
		rich("[color=#e8c788][font_size=25]" + CHAPTERS[i][0] + "[/font_size][/color]", col)
		for id in seen:
			var s: Dictionary = seen[id]
			if int(s.chapter) == i:
				rich("[b]" + str(s.title) + "  •  " + str(s.ref) + "[/b]\n" + passage(str(s.ref)), col)
				button("Read " + str(s.ref).get_slice(":", 0), open_reference.bind(str(s.ref)), col)
	button("Story chapters", show_chapters)

func show_reader() -> void:
	menu_view = "reader"
	clear_modal("The Holy Bible • KJV", "All 66 books  •  Offline reading  •  Search the text of the whole Bible")
	var nav := HBoxContainer.new()
	modal_content.add_child(nav)
	reader_book = OptionButton.new()
	reader_book.custom_minimum_size = Vector2(245, 44)
	for book in bible:
		reader_book.add_item(str(book.book))
	nav.add_child(reader_book)
	reader_chapter = OptionButton.new()
	reader_chapter.custom_minimum_size = Vector2(130, 44)
	nav.add_child(reader_chapter)
	button("Previous", reader_step.bind(-1), nav)
	button("Next", reader_step.bind(1), nav)
	reader_book.item_selected.connect(reader_select_book)
	reader_chapter.item_selected.connect(reader_select_chapter)
	var search_row := HBoxContainer.new()
	modal_content.add_child(search_row)
	search_box = LineEdit.new()
	search_box.placeholder_text = "Search a word or phrase: ark, Joseph, mercy…"
	search_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	search_row.add_child(search_box)
	button("Search", reader_search, search_row)
	search_box.text_submitted.connect(func(_t: String): reader_search())
	reader_text = RichTextLabel.new()
	reader_text.bbcode_enabled = true
	reader_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	reader_text.add_theme_font_size_override("normal_font_size", 22)
	reader_text.add_theme_color_override("default_color", Color("ede1c7"))
	reader_text.meta_clicked.connect(reader_search_click)
	modal_content.add_child(reader_text)
	reader_book.select(bible_book)
	reader_select_book(bible_book, false)
	reader_chapter.select(bible_chapter)
	update_reader()

func reader_select_book(index: int, reset: bool = true) -> void:
	bible_book = index
	if reset:
		bible_chapter = 0
	reader_chapter.clear()
	for i in range(bible[index].chapters.size()):
		reader_chapter.add_item("Chapter " + str(i + 1))
	bible_chapter = clampi(bible_chapter, 0, bible[index].chapters.size() - 1)
	reader_chapter.select(bible_chapter)
	update_reader()

func reader_select_chapter(index: int) -> void:
	bible_chapter = index
	update_reader()

func update_reader() -> void:
	var book: Dictionary = bible[bible_book]
	var chapter: Dictionary = book.chapters[bible_chapter]
	var text := "[font_size=28][color=#e8c788]" + str(book.book) + " " + str(bible_chapter + 1) + "[/color][/font_size]\n\n"
	for verse in chapter.verses:
		text += "[color=#c7a975]" + str(verse.verse) + "[/color]  " + str(verse.text) + "\n\n"
	reader_text.text = text
	reader_text.scroll_to_line(0)

func reader_step(step: int) -> void:
	bible_chapter += step
	if bible_chapter < 0:
		bible_book = posmod(bible_book - 1, bible.size())
		bible_chapter = bible[bible_book].chapters.size() - 1
	elif bible_chapter >= bible[bible_book].chapters.size():
		bible_book = posmod(bible_book + 1, bible.size())
		bible_chapter = 0
	reader_book.select(bible_book)
	reader_select_book(bible_book, false)

func reader_search() -> void:
	var query := search_box.text.strip_edges().to_lower()
	if query.length() < 2:
		reader_text.text = "Enter at least two characters."
		return
	var results := "[color=#e8c788][font_size=27]Search: " + query.replace("[", "") + "[/font_size][/color]\n\n"
	var count := 0
	for bi in range(bible.size()):
		var book: Dictionary = bible[bi]
		for ci in range(book.chapters.size()):
			for verse in book.chapters[ci].verses:
				if str(verse.text).to_lower().contains(query):
					if count < 200:
						results += "[url=" + str(bi) + ":" + str(ci) + "][color=#e8c788]" + str(book.book) + " " + str(ci + 1) + ":" + str(verse.verse) + "[/color][/url]\n" + str(verse.text) + "\n\n"
					count += 1
	reader_text.text = str(count) + " matches. Showing first " + str(mini(count, 200)) + ". Click a reference to read its chapter.\n\n" + results
	reader_text.scroll_to_line(0)

func reader_search_click(meta: Variant) -> void:
	var parts := str(meta).split(":")
	bible_book = int(parts[0])
	bible_chapter = int(parts[1])
	reader_book.select(bible_book)
	reader_select_book(bible_book, false)

func open_reference(ref: String) -> void:
	var space := ref.rfind(" ")
	var name_text := ref.substr(0, space)
	for i in range(bible.size()):
		if str(bible[i].book).replace(" ", "").to_lower() == name_text.replace(" ", "").to_lower():
			bible_book = i
			bible_chapter = int(ref.substr(space + 1).get_slice(":", 0)) - 1
	show_reader()

func show_settings() -> void:
	menu_view = "settings"
	clear_modal("Settings & controls")
	var col := scroll_column()
	rich("WASD or arrow keys: walk\nMouse: look around\nShift: run   •   Space: jump\nE: interact with the nearest golden marker\nM: chapters   •   J: journal   •   B: complete Bible\nTab: chapter map   •   Q: objectives\nR: return to the chapter entrance\nEscape: menu and release the mouse\n\nIf you feel lost, follow the direction and distance in the top-left panel. Every story is unlocked. There is no combat, health loss, or time limit.", col)
	var sound := CheckButton.new()
	sound.text = "Ambient sound"
	sound.button_pressed = not AudioServer.is_bus_mute(0)
	sound.toggled.connect(func(on: bool): AudioServer.set_bus_mute(0, not on))
	col.add_child(sound)
	var shadows := CheckButton.new()
	shadows.text = "Shadows (turn off for slower PCs)"
	shadows.button_pressed = sun.shadow_enabled
	shadows.toggled.connect(func(on: bool): sun.shadow_enabled = on; quality_low = not on)
	col.add_child(shadows)
	col.add_child(text_label("Mouse sensitivity", 18))
	var sensitivity := HSlider.new()
	sensitivity.min_value = 0.0008
	sensitivity.max_value = 0.006
	sensitivity.step = 0.0002
	sensitivity.value = player.sensitivity
	sensitivity.value_changed.connect(func(value: float): player.sensitivity = value)
	col.add_child(sensitivity)
	button("Save progress now", func(): save_game(); message("Progress saved"), col)
	button("Main menu", show_home, col)

func rescue() -> void:
	player.position = world.spawn
	player.velocity = Vector3.ZERO
	player.rotation = Vector3.ZERO
	player.camera.rotation = Vector3.ZERO
	message("Returned to the chapter entrance")
	save_game()

func save_game() -> void:
	if not is_instance_valid(player):
		return
	chapter_locations[str(current_chapter)] = {"position": [player.position.x, player.position.y, player.position.z], "yaw": player.rotation.y, "pitch": player.camera.rotation.x}
	var data := {"locations": chapter_locations, "chapter": current_chapter, "position": [player.position.x, player.position.y, player.position.z], "yaw": player.rotation.y, "pitch": player.camera.rotation.x, "seen": seen, "actions": actions}
	var file := FileAccess.open(SAVE_PATH + ".tmp", FileAccess.WRITE)
	if file == null:
		message("Could not save progress. Check write access.")
		return
	file.store_string(JSON.stringify(data))
	file.close()
	var err := DirAccess.rename_absolute(SAVE_PATH + ".tmp", SAVE_PATH)
	if err != OK:
		message("Could not finish saving progress.")

func load_save() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var data = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	if not data is Dictionary:
		return
	save_data = data
	chapter_locations = data.get("locations", {})
	current_chapter = clampi(int(data.get("chapter", 0)), 0, CHAPTERS.size() - 1)
	seen = data.get("seen", {})
	actions = data.get("actions", {})

func quit_game() -> void:
	save_game()
	stop_audio()
	await get_tree().create_timer(0.15).timeout
	get_tree().quit()

func stop_audio() -> void:
	if is_instance_valid(ambience):
		ambience.stop()
		ambience.stream = null
	if is_instance_valid(rain_sound):
		rain_sound.stop()
		rain_sound.stream = null

func _exit_tree() -> void:
	stop_audio()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		quit_game()

func smoke_test() -> void:
	# Executed only with --smoke-test. Does not run during normal play.
	assert(bible.size() == 66)
	assert(passage("Genesis 6:14").begins_with("Make thee an ark"))
	for i in range(CHAPTERS.size()):
		load_chapter(i)
		await get_tree().process_frame
		assert(world.spots.size() >= 5)
		assert(world.spots.size() == chapter_total(i))
		for s in world.spots:
			assert(not passage(s.ref).is_empty(), "Missing passage " + str(s.ref))
			show_spot(s)
			await get_tree().process_frame
		show_chapters()
		show_journal()
		show_settings()
		show_map()
		show_objectives()
		show_reader()
		reader_step(1)
		reader_step(-1)
		search_box.text = "Joseph"
		reader_search()
		assert(reader_text.text.contains("matches"))
		if i == 5:
			world.trigger("part")
		if i == 1:
			world.trigger("rain")
			world.trigger("dove")
			world.trigger("rainbow")
		await get_tree().process_frame
	print("SMOKE TEST PASS: 10 worlds, 58 markers, 66 books, all passage references, menus, journal, search and event creation.")
	stop_audio()
	await get_tree().create_timer(0.2).timeout
	get_tree().quit()

func required_actions(index: int) -> Array:
	var all := [["timber", "provisions"], ["rain", "dove", "rainbow"], ["dream"], ["collect_0", "collect_1", "collect_2", "share"], [], ["part"], [], ["stone_0", "stone_1", "stone_2", "stone_3", "stone_4", "david_event"], ["daniel_pray", "daniel_peace", "daniel_dawn"], ["jonah_storm", "jonah_pray", "jonah_mercy"]]
	return all[index]

func objective_name(action: String) -> String:
	var names := {"timber": "Gather timber", "provisions": "Store provisions", "rain": "Begin the rain", "dove": "See the returning dove", "rainbow": "Reveal the covenant bow", "dream": "Illustrate Joseph's dream", "share": "Share the stored grain", "part": "Part the waters", "david_event": "Witness the confrontation", "daniel_pray": "Daniel's prayer moment", "daniel_peace": "Let the lions settle", "daniel_dawn": "Witness the dawn", "jonah_storm": "Begin the storm", "jonah_pray": "Read Jonah's prayer and reveal the calm light", "jonah_mercy": "Witness Nineveh's response"}
	if action.begins_with("stone_"):
		return "Collect smooth stone " + str(int(action.get_slice("_", 1)) + 1)
	if action.begins_with("collect_"):
		return "Collect grain " + str(int(action.get_slice("_", 1)) + 1)
	return names.get(action, action)

func next_objective(index: int) -> String:
	var done: Array = actions.get(str(index), [])
	for action in required_actions(index):
		if not done.has(action):
			return objective_name(str(action))
	if chapter_count(index) < chapter_total(index):
		return "Read the remaining discovery passages"
	return ""

func chapter_total(index: int) -> int:
	return [5, 5, 5, 8, 5, 5, 5, 8, 6, 6][index]

func chapter_complete(index: int) -> bool:
	return next_objective(index).is_empty()

func show_objectives() -> void:
	menu_view = "objectives"
	clear_modal("Journey objectives", "Explore at your own pace. Checkmarks record story tasks and discoveries; they do not score faith or belief.")
	var col := scroll_column()
	var completed := 0
	for i in range(CHAPTERS.size()):
		if chapter_complete(i):
			completed += 1
	rich("[color=#e8c788]" + str(completed) + " / 10 chapters fully explored[/color]", col)
	for i in range(CHAPTERS.size()):
		var text: String = "[b]" + CHAPTERS[i][0] + "[/b]  " + ("✓" if chapter_complete(i) else "") + "\nPassages: " + str(chapter_count(i)) + " / " + str(chapter_total(i)) + "\n"
		var done: Array = actions.get(str(i), [])
		for action in required_actions(i):
			text += ("✓  " if done.has(action) else "○  ") + objective_name(str(action)) + "\n"
		rich(text, col)
		button("Explore this chapter", enter_chapter.bind(i), col)
	button("Map of this chapter", show_map)

func select_waypoint(id: String) -> void:
	waypoint_id = id
	close_modal()
	message("Destination set. Follow the direction and distance at top left.")

func show_map() -> void:
	menu_view = "map"
	clear_modal("Chapter map  •  " + CHAPTERS[current_chapter][0], "Gold: unread passage   •   Green: read passage   •   Blue: your position and view direction")
	var map := MapScript.new()
	map.spots = world.spots
	map.seen = seen
	map.player_position = player.position
	map.player_yaw = player.rotation.y
	map.chapter = current_chapter
	map.chosen = waypoint_id
	map.waypoint_selected.connect(select_waypoint)
	modal_content.add_child(map)
	var row := HBoxContainer.new()
	modal_content.add_child(row)
	var destinations := OptionButton.new()
	destinations.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for s in world.spots:
		destinations.add_item(("✓  " if seen.has(s.id) else "○  ") + str(s.title))
	row.add_child(destinations)
	button("Set destination", func(): select_waypoint(str(world.spots[destinations.selected].id)), row)
	button("Clear destination", func(): waypoint_id = ""; close_modal(), row)
	button("Journey objectives", show_objectives, row)

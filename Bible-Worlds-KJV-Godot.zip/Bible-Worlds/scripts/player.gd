extends CharacterBody3D

var camera: Camera3D
var active := false
var sensitivity := 0.0024
var walking_time := 0.0

func _ready() -> void:
	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.height = 1.8
	capsule.radius = 0.32
	shape.shape = capsule
	shape.position.y = 0.9
	add_child(shape)
	camera = Camera3D.new()
	camera.position.y = 1.6
	camera.fov = 78
	camera.current = true
	add_child(camera)
	floor_snap_length = 0.5

func _unhandled_input(event: InputEvent) -> void:
	if active and event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * sensitivity)
		camera.rotation.x = clampf(camera.rotation.x - event.relative.y * sensitivity, -1.3, 1.3)

func _physics_process(delta: float) -> void:
	if not active:
		velocity = Vector3.ZERO
		return
	var dir := Input.get_vector("left", "right", "forward", "back")
	var move := transform.basis * Vector3(dir.x, 0, dir.y)
	var speed := 9.0 if Input.is_action_pressed("sprint") else 5.0
	velocity.x = move.x * speed
	velocity.z = move.z * speed
	if not is_on_floor():
		velocity.y -= 22.0 * delta
	elif Input.is_action_just_pressed("jump"):
		velocity.y = 7.0
	move_and_slide()
	if position.y < -15:
		get_parent().rescue()
	if dir.length() > 0.1 and is_on_floor():
		walking_time += delta * 8.0
		camera.position.y = 1.6 + sin(walking_time) * 0.035
	else:
		camera.position.y = lerpf(camera.position.y, 1.6, delta * 8.0)

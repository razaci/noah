BIBLE WORLDS — KJV EXPLORER
===========================
A complete Godot 4 project with ten peaceful 3D exploration chapters.
Tested with Godot 4.5.1 standard (no .NET needed).

PLAY ON WINDOWS
1. Extract the entire ZIP into a folder.
2. Open Godot 4, click Import, and select project.godot in Bible-Worlds.
3. Open the project and press F5. Click Continue exploring or choose a chapter.
   Godot imports the included sounds automatically on first opening.

Alternatively, run PLAY-WINDOWS.bat and select your Godot 4 executable.
This ZIP is a Godot source project, not a compiled Windows executable.
Godot itself is not included. Once imported, the game works offline.

CONTROLS
WASD / arrows: walk; mouse: look; Shift: run; Space: jump.
E: read / interact with the nearest golden discovery marker.
M: story chapters; J: passage journal; B: complete KJV reader.
Tab: chapter map; Q: journey objectives.
Click a marker on the map, or select it from the list, to set a destination.
The map sets a compass waypoint; you walk there yourself.
R: return to this chapter's entrance; Esc: menu / free the mouse.
In menus, click buttons with the mouse. Escape returns to the world.
Follow the direction and distance shown at top left when looking for markers.

TEN CHAPTERS
1. Noah — The Ark: enter the open front, walk the aisle, see animal stalls,
   gather timber and store provisions.
2. Noah — Above the Waters: explore the deck, begin the rain and rising water,
   animate the returning dove and reveal the covenant bow.
3. Joseph — Canaan: the coat, sheaves, safe symbolic pit and caravan route.
4. Joseph — Egypt: walk the palace, prison and granary. Collect three grain
   tokens behind the storehouse before sharing the stored grain.
5. Moses — The Burning Bush: shepherd's wilderness, flame and call at Horeb.
6. Moses — The Red Sea: interact with Moses' marker and choose Part the waters.
   Wait for the short animation, then walk forward along the dry corridor.
7. Moses — Mount Sinai: explore the camp, covenant and symbolic tablets.

8. David — The Valley of Elah: visit the two camps, collect five smooth stones,
   and begin the non-graphic sling-and-stone illustration near Goliath.
9. Daniel — The Lions' Den: walk inside the den, read Daniel's prayer, let the
   lions settle, then bring the dawn. The lions do not attack the player.
10. Jonah — The Sea and Nineveh: visit the ship, begin the tempest, explore
   the symbolic great-fish chamber, reveal calm light after reading Jonah's
   prayer, and walk to Nineveh to witness the city's response.

The Q objectives panel shows discoveries and story tasks for all ten chapters.
Some events need their preceding task: collect all five stones for David;
prayer precedes resting lions and dawn; Jonah's storm precedes the prayer
moment and the city response. Checkmarks record game progress, not belief.

SCRIPTURE AND SAVING
58 discovery markers quote KJV verses with their references.
The complete offline reader contains 66 books, 1,189 chapters, 31,102 verses.
Choose book/chapter, use previous/next, or search a word/phrase.
Search shows the first 200 results and counts all matches. Click any result
reference to read its full chapter. The journal preserves discovered passages.

Discoveries, completed events and the last chapter/position/view save every
10 seconds, on interaction, on chapter changes and when quitting normally.
Each chapter now retains its own last position and view direction when revisited.
Existing saves from the first edition still load.
On Windows the save is in:
%APPDATA%\Godot\app_userdata\Bible Worlds — KJV Explorer\bible_worlds_save.json
The source ZIP does not include a prefilled save. Every chapter is unlocked.

VISUALS AND PERFORMANCE
Original low-poly models generated in code; no external art services needed.
Compatibility renderer; optional shadows; looping generated wind/rain sounds.
Settings include mouse sensitivity, ambient sound and shadows.
There is no combat, time limit, damage or punitive failure.

This is an artistic exploration of the stories, not a historical reconstruction.
The environment scale, visual designs, timing and tasks are invented. Scripture
panels use KJV wording; scene notes are clearly labeled separately.
The scenery is intentionally stylized, not photorealistic. Animals and story
figures are simple low-poly models, not voice-acted cinematic characters.

EDIT / EXPORT
Main scene: main.tscn. Gameplay/UI: scripts/main.gd.
World building and visual events: scripts/world.gd. Movement: scripts/player.gd.
Bible text: data/kjv.json. Generated ambient audio: audio/.
To make an EXE: install Godot export templates matching your engine version,
then Project > Export > Add > Windows Desktop. Include *.json in the non-resource
export filter so the Bible data is packaged. An export preset is provided.

Third-party KJV data attribution and MIT license: THIRD-PARTY-LICENSES.txt.
Source: https://github.com/aruljohn/Bible-kjv
